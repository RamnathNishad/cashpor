export class UserDetails {
    id:number=0;
    uname:string="";
    password:string="";
    email:string="";
    city:string="";
    state:string="";
    phone:string="";
    pin:string="";
    picture:string="assets/images/1.jpg";

    constructor(id:number,uname:string,password:string,email:string,city:string,state:string,phone:string,pin:string,picture:string){
        this.id=id;
        this.uname=uname;
        this.password=password;
        this.email=email;
        this.city=city;
        this.state=state;
        this.phone=phone;
        this.picture=picture;
        this.pin=pin;
    }
}
