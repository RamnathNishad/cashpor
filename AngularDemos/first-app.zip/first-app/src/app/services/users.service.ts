import { Injectable } from '@angular/core';
import { UserDetails } from '../models/user-details';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UsersService {

  baseUrl:string="http://localhost:5028/api/Users/";

  constructor(private http:HttpClient) { }

  getUsers():Observable<UserDetails[]>{       
    return this.http.get<UserDetails[]>(this.baseUrl+"getusers");
  }

  registerUser(user:UserDetails){
    this.http.post(this.baseUrl+"adduser",user)
              .subscribe(response=>{
                            console.log("record inserted");
                          });    
  }
  getUserById(id:number):Observable<UserDetails>{
    return this.http.get<UserDetails>(this.baseUrl+"getuserbyid/"+id.toString());              
  }
}
