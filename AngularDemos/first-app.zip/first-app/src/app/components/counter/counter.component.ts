import { Component, Input, input } from '@angular/core';

@Component({
  selector: 'app-counter',
  standalone: true,
  imports: [],
  templateUrl: './counter.component.html',
  styleUrl: './counter.component.css'
})
export class CounterComponent {
  @Input()
  counter:number=0;   

  constructor(){
        
  }

  increment(){
    this.counter++;
  }
  decrement(){
    this.counter--;
  }
}
