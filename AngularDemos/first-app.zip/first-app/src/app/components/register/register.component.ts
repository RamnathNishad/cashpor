import { CommonModule, NgIf } from '@angular/common';
import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { UsersService } from '../../services/users.service';

@Component({
  selector: 'register',
  standalone: true,
  imports: [ReactiveFormsModule,NgIf],
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {
  fg:FormGroup;

  constructor(private service:UsersService){
    this.fg=new FormGroup({
      id:new FormControl(0,Validators.required),
      uname:new FormControl("",Validators.compose([Validators.required,
                                                    Validators.minLength(5)])),
      password:new FormControl("",Validators.required),
      email:new FormControl("",Validators.required),
      city:new FormControl("",Validators.required),
      state:new FormControl("",Validators.required),
      phone:new FormControl("",Validators.required),
      pin:new FormControl("",Validators.required),
      picture:new FormControl("",Validators.required)
    });
  }

  registerUser(){
    //console.log(this.fg.value);
    this.service.registerUser(this.fg.value);
  }

}
