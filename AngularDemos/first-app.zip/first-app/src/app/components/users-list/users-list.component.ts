import { Component } from '@angular/core';
import { UserDetails } from '../../models/user-details';
import { CommonModule } from '@angular/common';
import { GenderPipe } from '../../pipes/gender.pipe';
import { UsersService } from '../../services/users.service';

@Component({
  selector: 'users-list',
  standalone: true,
  imports: [UsersListComponent,CommonModule,GenderPipe],
  templateUrl: './users-list.component.html',
  styleUrl: './users-list.component.css'
})
export class UsersListComponent {
 users:UserDetails[]=[];
 imageBorderStyle={"border-radius": "5px"};

 gender:string="Male";

 constructor(private service:UsersService){
   this.service.getUsers().subscribe(res=>{
    this.users=res;
  });
 }
}
