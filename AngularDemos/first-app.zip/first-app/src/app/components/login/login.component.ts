import { Component } from '@angular/core';
import { UserDetails } from '../../models/user-details';
import { FormsModule } from '@angular/forms';
import { CommonModule, JsonPipe } from '@angular/common';

@Component({
  selector: 'login',
  standalone: true,
  imports: [FormsModule,JsonPipe,CommonModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  userDetails:UserDetails=new UserDetails(0,"","","","","","","","");

  loginUser(){
    console.log(this.userDetails);
  }
}
