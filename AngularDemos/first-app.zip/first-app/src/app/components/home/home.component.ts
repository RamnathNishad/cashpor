import { Component } from '@angular/core';
import { UserDetails } from '../../models/user-details';
import { UsersService } from '../../services/users.service';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent {

  userDetails:UserDetails=new UserDetails(0,"","","","","","","","");

  constructor(private service:UsersService){
    this.service.getUserById(1)
                .subscribe(res=>this.userDetails=res);
  }
}
